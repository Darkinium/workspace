package net.mcreator.darkium.procedures;

import net.mcreator.darkium.DarkiumElements;

@DarkiumElements.ModElement.Tag
public class DarkiumOrePlayerStartsToDestroyProcedure extends DarkiumElements.ModElement {
	public DarkiumOrePlayerStartsToDestroyProcedure(DarkiumElements instance) {
		super(instance, 2);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}

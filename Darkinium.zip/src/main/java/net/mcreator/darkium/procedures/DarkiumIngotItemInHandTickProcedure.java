package net.mcreator.darkium.procedures;

import net.mcreator.darkium.DarkiumElements;

@DarkiumElements.ModElement.Tag
public class DarkiumIngotItemInHandTickProcedure extends DarkiumElements.ModElement {
	public DarkiumIngotItemInHandTickProcedure(DarkiumElements instance) {
		super(instance, 16);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}

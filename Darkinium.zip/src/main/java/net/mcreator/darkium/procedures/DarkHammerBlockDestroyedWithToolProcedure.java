package net.mcreator.darkium.procedures;

import net.mcreator.darkium.DarkiumElements;

@DarkiumElements.ModElement.Tag
public class DarkHammerBlockDestroyedWithToolProcedure extends DarkiumElements.ModElement {
	public DarkHammerBlockDestroyedWithToolProcedure(DarkiumElements instance) {
		super(instance, 54);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}

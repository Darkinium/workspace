package net.mcreator.darkium.procedures;

import net.mcreator.darkium.DarkiumElements;

@DarkiumElements.ModElement.Tag
public class DarkCompressorOnBlockRightClickedProcedure extends DarkiumElements.ModElement {
	public DarkCompressorOnBlockRightClickedProcedure(DarkiumElements instance) {
		super(instance, 33);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}
